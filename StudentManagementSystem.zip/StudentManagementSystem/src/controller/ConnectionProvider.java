/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;
import java.sql.*;
import model.Student;

/**
 *
 * @author BC-STUDENT
 */
public class ConnectionProvider {
    String username = "postgres";
    String password = "belgiumcampus";
    
    private static final String url = "jdbc:postgresql://localhost:5432/StudentManagementSystemDB";
    private static final String driver = "org.postgresql.Driver";
    
    Connection conn = null;
    
    
    public Connection connect() throws ClassNotFoundException {
        try {
            Class.forName("org.postgresql.Driver");
            this.conn = DriverManager.getConnection(url, username, password);
            if (this.conn != null) {
                System.out.println("Connected to database");
            }
        } catch (SQLException ex) {
            System.out.println("Could not connect: " + ex.getMessage());
        }
        return conn;
    }
    
    public boolean add(Student student) throws ClassNotFoundException {
        boolean status = false;
        Connection connection;
        String sql = "INSERT INTO Student(student_number, first_name, last_name, qualification)"
                + "VALUES(?, ?, ?, ?)";
        
        try {
            connection = connect();
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(0, student.getStudentNumber());
            ps.setString(1, student.getFirstName());
            ps.setString(2, student.getLastName());
            ps.setString(3, student.getQualification());
            
            int rows = ps.executeUpdate();
            
            if (rows > 0) status = true;
        } catch (SQLException ex) {
            System.out.println("Could not add data: " + ex.getMessage());
        }
        return status;
    }
}
